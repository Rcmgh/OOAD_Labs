package com.assignment.superMarket.service;

import com.assignment.superMarket.model.Product;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductService extends JpaRepository<Product,Integer> {

    Product save(Product product);

    @Override
    List<Product> findAll();

    @Transactional
    void deleteById(int id);
}
