package com.assignment.superMarket.controller;

import com.assignment.superMarket.model.Product;
import com.assignment.superMarket.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import java.util.List;


@Controller
public class ProductController {
    @Autowired
    private ProductService productService;

    @GetMapping("/")
    public String displayHome() {
        return "home.html";
    }

    @GetMapping("/view")
    public ModelAndView viewPage() {
        ModelAndView m = new ModelAndView();
        List<Product> products = productService.findAll();
        m.addObject("products", products);
        m.setViewName("view.html");
        return m;
    }

    @GetMapping("/insert")
    public String insertPage() {
        return "insert.html";
    }

    @GetMapping("/delete")
    public String deletePage() {
        return "delete.html";
    }

    @PostMapping("/insert")
    public RedirectView insertProduct(@RequestParam("name") String name,
                                      @RequestParam("category") String category,
                                      @RequestParam("description") String description,
                                      @RequestParam("price") double price,
                                      @RequestParam("stock") int stock,
                                      @RequestParam("expiration-date") String expirationDate) {
        try {
            productService.save(new Product(name, category, description, price, stock, expirationDate));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new RedirectView("/view");
    }

    @PostMapping("/delete")
    public RedirectView deleteProduct(@RequestParam("id") int id) {
        try {
            productService.deleteById(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new RedirectView("/view");
    }
}
