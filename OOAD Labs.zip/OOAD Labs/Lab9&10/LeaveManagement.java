import java.util.Date;
import java.util.Scanner;
class Leave
{
String empName;
String leaveType;
String leaveStatus;
String approvedBy;
Date requestDate;
Date approvalDate;
Date startDate;
Date endDate;
String reason;
}
class Employee
{
String name;
}
class LeaveManagementSystem
{
Employee employee;
Leave leave;
public LeaveManagementSystem(Employee employee, Leave leave)
{
this.employee = employee;
this.leave = leave;
}
public void applyLeave()
{
Scanner scanner = new Scanner(System.in);
System.out.print("Enter leave type: ");
leave.leaveType = scanner.nextLine();
if(leave.leaveType.equalsIgnoreCase("CL") ||
leave.leaveType.equalsIgnoreCase("SL"))
{
System.out.print("Enter reason: ");
leave.reason = scanner.nextLine();
}
else if(leave.leaveType.equalsIgnoreCase("VL"))
{
System.out.print("Enter start date: ");
leave.startDate = new Date(scanner.nextLine());
System.out.print("Enter end date: ");
leave.endDate = new Date(scanner.nextLine());
}
leave.leaveStatus = "New";
leave.requestDate = new Date();
System.out.println("Leave applied successfully.");
}
public void processLeave()
{
if(leave.leaveType.equalsIgnoreCase("SL")) {
processSL();
} else if(leave.leaveType.equalsIgnoreCase("CL")) {
processCL();
} else if(leave.leaveType.equalsIgnoreCase("VL")) {
processVL();
}
}
private void processSL()
{
leave.approvedBy = "Tech Lead";
leave.approvalDate = new Date();
leave.leaveStatus = "Approved";
System.out.println("Leave processed successfully.");
System.out.println("Request details: " + leave.empName + " " + leave.leaveType
+ " " + leave.leaveStatus + " " + leave.approvedBy + " " + leave.requestDate);
System.out.println("Approval details: " + leave.leaveStatus + " " +
leave.approvalDate);
}
private void processCL()
{
leave.approvedBy = "Project Manager";
leave.approvalDate = new Date();
leave.leaveStatus = "Approved";
System.out.println("Leave processed successfully.");
System.out.println("Request details: " + leave.empName + " " + leave.leaveType
+ " " + leave.leaveStatus + " " + leave.approvedBy + " " + leave.requestDate);
System.out.println("Approval details: " + leave.leaveStatus + " " +
leave.approvalDate);
}
private void processVL()
{
leave.approvedBy = "Director";
leave.approvalDate = new Date();
leave.leaveStatus = "Approved";
System.out.println("Leave processed successfully.");
System.out.println("Request details: " + leave.empName + " " + leave.leaveType
+ " " + leave.leaveStatus + " " + leave.approvedBy + " " + leave.requestDate);
System.out.println("Approval details: " + leave.leaveStatus + " " +
leave.approvalDate);
}
}
public class LeaveManagement {
public static void main(String[] args)
{
Scanner s = new Scanner(System.in);
Employee employee = new Employee();
Leave leave = new Leave();
System.out.print("Enter employee name: ");
employee.name = s.nextLine();
leave.empName = employee.name;
LeaveManagementSystem lms = new LeaveManagementSystem(employee, leave);
lms.applyLeave();
lms.processLeave();
}
}