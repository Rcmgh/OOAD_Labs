import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class TestUser {

    public static void main(String args[]) throws UnknownHostException, InterruptedException {
      // print the login name and the IP Address
      System.out.println("User name is: " + System.getProperty("user.name") );
      InetAddress localHost = InetAddress.getLocalHost();
      System.out.println("IP Address is :" + localHost.getHostAddress());
      
      // Read input for number of runners
        int numRunners = Integer.parseInt(args[0]);
        
        // Create and start threads for each runner
        List<RunnerThread> threads = new ArrayList<>();
        for (int i = 0; i < numRunners; i++) {
            RunnerThread thread = new RunnerThread("Runner " + (i+1));
            threads.add(thread);
            thread.start();
        }
        
        // Wait for a runner to reach 1000 meters
        boolean winnerFound = false;
        while (!winnerFound) {
            for (RunnerThread thread : threads) {
                if (thread.getDistance() >= 1000) {
                    winnerFound = true;
                    break;
                }
            }
            Thread.sleep(1000);
        }
        
        // Stop all threads and print top 3 runners
        for (RunnerThread thread : threads) {
            thread.interrupt();
            thread.join();
        }
        Collections.sort(threads);
        System.out.println("Top 3 runners:");
        for (int i = 0; i < 3; i++) {
            System.out.println(threads.get(i));
        }
    }

 // RunnerThread class represents a single runner thread
    private static class RunnerThread extends Thread implements Comparable<RunnerThread> {
        private final String name;
        private int distance;
        
        public RunnerThread(String name) {
            this.name = name;
        }
        
        public int getDistance() {
            return distance;
        }
        
        @Override
        public void run() {
            Random random = new Random();
            try {
                while (!isInterrupted()) {
                    int distanceCovered = random.nextInt(6) + 5; // Random distance between 5-10 meters
                    distance += distanceCovered;
                    System.out.println(name + " has covered " + distance + " meters");
                    Thread.sleep(1000);
                }
            } catch (InterruptedException e) {
                System.out.println(name + " has been interrupted");
            }
        }
        
        @Override
        public int compareTo(RunnerThread other) {
            return Integer.compare(other.distance, this.distance); // Sort in descending order
        }
        
        @Override
        public String toString() {
            return name + " - " + distance + " meters";
        }
    }

}


